Theme Name: CMS
Theme URI: http://www.bravenewcode.com/wptouch-pro/
Description: A new WPtouch Pro theme made for content-heavy sites. Includes support for a featured slider, custom post types, multiple menus, and more.
Version: 1.1.3
Stable tag: 1.1.3
Depends on: 3.1
Parent: Foundation
Author: BraveNewCode Inc.
Tags: smartphone