Theme Name: Classic Redux
Theme URI: http://www.bravenewcode.com/products/wptouch-pro/
Description: A new take on the famous original WPtouch theme.
Version: 1.1.5
Stable tag: 1.1.5
Depends on: 3.1
Author: BraveNewCode Inc.
Parent: Foundation
Tags: smartphone, tablet
