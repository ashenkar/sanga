Theme Name: Simple
Theme URI: http://www.bravenewcode.com/products/wptouch-pro/
Description: Designed for page-driven sites for individuals, small businesses, agencies and shops. An easily brandable mobile theme.
Version: 1.1.3
Stable tag: 1.1.3
Depends on: 3.1
Author: BraveNewCode Inc.
Parent: Foundation
Tags: smartphone