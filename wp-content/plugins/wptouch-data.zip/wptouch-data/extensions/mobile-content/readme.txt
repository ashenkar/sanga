Extension Name: Mobile Content
Description: Allows mobile-specific content to be shown instead of your regular content on posts & pages
Version: 1.0.1
Stable tag: 1.0.1
Depends-on: 3.1
Author: BraveNewCode Inc.

== Changelog ==

= Version 1.0.1 =

* Fixed: Mobile content is now substituted earlier for better compatibility with plugins relying on post_content (e.g., Royal Slider)