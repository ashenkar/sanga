<h4 id="bnc-help-h4"><?php _e( 'WPtouch Help & Account Links', 'wptouch-pro' ); ?></h4>
<ul id="bnc-help-menu">
	<li><a href="https://support.wptouch.com/support/tickets/" target="_blank"><?php _e( 'Support', 'wptouch-pro' ); ?></a></li>
	<li><a href="https://support.wptouch.com/support/solutions/" target="_blank"><?php _e( 'Documentation', 'wptouch-pro' ); ?></a></li>
	<li><a href="https://www.wptouch.com/account/" target="_blank"><?php _e( 'Account & Downloads', 'wptouch-pro' ); ?></a></li>
	<li><a href="http://twitter.com/wptouch" target="_blank"><?php _e( 'BraveNewCode on Twitter', 'wptouch-pro' ); ?></a></li>
	<li><a href="http://www.wptouch.com/terms/" target="_blank"><?php _e( 'Plugin Licensing Terms', 'wptouch-pro' ); ?></a></li>
</ul>