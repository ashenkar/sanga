<label class="textarea" for="wptouch_restore_settings">
	<?php _e( 'Please paste your encoded settings below and save to restore your settings.', 'wptouch-pro' ); ?>
</label>
<textarea rows="15" name="wptouch_restore_settings"></textarea>