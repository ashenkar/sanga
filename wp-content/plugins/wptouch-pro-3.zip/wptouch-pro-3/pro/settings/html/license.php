<div id="license-area-left">
	<h2><?php e_( 'License Details', 'wptouch-pro' ); ?></h2>
</div>

<div id="license-area-right">
	<!-- Ajaxed license details -->
</div>